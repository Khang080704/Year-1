#include <iostream>
#include <fstream>
#include <math.h>
#include <string.h>
#include <iomanip>
using namespace std;

typedef struct
{
	char name[50];
	long long id;
	double diem[3];
    double diemTB;
}SinhVien;

SinhVien sv[50];
const int Max = 3;

int getArrayFromFile(string filename, SinhVien* sv);
void writeToFile(string filename, SinhVien* sv, int n);
void basicInfo(SinhVien* sv, int i);
void queries(SinhVien* sv, int n);
int main() {
    string filename = "Input.txt";
    string fileOutput = "Output.txt";
    int n = getArrayFromFile(filename, sv);
    writeToFile(fileOutput, sv, n);
    queries(sv, n);

    return 0;
}
int getArrayFromFile(string filename, SinhVien* sv) {
    ifstream reader(filename, ios::in);
    char number[10];
    int n = 0;
    char temp_id[10];
    char temp_diem[10];
    string temp;
    
    while (!reader.eof()) {
        cout << "Ban muon nhap bao nhieu sinh vien: ";
        reader.getline(number, sizeof(number));
        n = atoi(number);
        cout << n << "\n";
        for (int i = 0; i < n; i++) {
            cout << "==============================================" << endl;
            reader.getline(sv[i].name, sizeof(sv[i].name));
            cout  <<  "Nhap ten sinh vien thu " << i + 1 << " : ";
            cout << sv[i].name << endl;

            cout << "Nhap id sinh vien thu " << i + 1 << " : ";
            reader.getline(temp_id, sizeof(temp_id), '\n');
            sv[i].id = atoi(temp_id);
            cout << sv[i].id << endl;
            sv[i].diemTB = 0;
            for (int j = 0; j < Max; j++) {
                cout << "Nhap diem thu " << j+1 << " cua sinh vien thu " << i + 1 << " : ";
                reader.getline(temp_diem, sizeof(temp_diem), '\n');
                sv[i].diem[j] = atof(temp_diem);
                cout << sv[i].diem[j] << endl;
                sv[i].diemTB += sv[i].diem[j];
            }
            sv[i].diemTB /= 3;
            cout << "Diem trung binh cua sinh vien thu " << i + 1 
                << " : " << setprecision(2)<< sv[i].diemTB << endl; 
            
        }

    }
    reader.close();
    return n;
}
void writeToFile(string filename, SinhVien* sv, int n) {
    ofstream writer(filename, ios::out);
    writer << setw(50) << "Danh sach sinh vien" << endl;
    for (int i = 0; i < n; i++) {
        writer << "==============================================" << endl;
        writer << "Sinh vien thu " << i + 1 << endl;
        writer << "Ten: ";
        writer << sv[i].name << endl;
        writer << "Id: ";
        writer << sv[i].id << endl;
        for (int j = 0; j < Max; j++) {
            writer << "Diem mon thu " << j + 1 << " : ";
            writer << sv[i].diem[j] << endl;
        }
        writer << "Diem trung binh " << Max << " mon: ";
        writer << setprecision(2) << sv[i].diemTB << endl;
    }
}
void basicInfo(SinhVien* sv, int i) {
    cout << "==============================================" << endl;
    cout << "Thong tin ma ban muon tim kiem" << endl;
    cout << "Ten: ";
    cout << sv[i].name << endl;
    cout << "Id: ";
    cout << sv[i].id << endl;
    for (int j = 0; j < Max; j++) {
        cout << "Diem mon thu " << j + 1 << " : ";
        cout << sv[i].diem[j] << endl;
    }
    cout << "Diem trung binh " << Max << " mon: ";
    cout << setprecision(2) << sv[i].diemTB << endl;
}
void queries(SinhVien* sv, int n) {
    char name[50];
    cout << "Nhap ten sinh vien ban muon tim kiem :";
    cin.getline(name, sizeof(name));
    int count_e = 0;
    for (int i = 0; i < n; i++) {
        if (strcmp(name,sv[i].name) == 0) {
            basicInfo(sv, i);
            count_e++;
        }
    }
    if (count_e == 0) {
        cout << "Sinh vien ma ban muon tim kiem khong co trong danh sach da nhap" << endl;
    }
    char Id[10];
    int count_id = 0;
    cout << "Nhap Id ma ban muon tim kiem :";
    cin.getline(Id, sizeof(Id));
    int id = atoi(Id);
    for (int i = 0; i < n; i++) {
        if (id == sv[i].id) {
            cout << "Thong tin ma ban muon tim kiem" << endl;
            basicInfo(sv, i);
        }
        count_id++;
    }
    if (count_id == 0) {
        cout << "Sinh vien ma ban muon tim kiem khong co trong danh sach da nhap" << endl;
    }
    for (int i = 0; i < n; i++) {
        cout << "Danh sach cac sinh vien co diem trung binh lon hon 7" << endl;
        int count = 0;
        if (sv[i].diemTB > 7) {
            basicInfo(sv, i);
            count++;
        }
        if (count == 0) {
            cout << "Khong co sinh vien nao co diem trung binh lon hon 7" << endl;
        }
    }
}